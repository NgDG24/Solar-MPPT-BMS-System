*PADS-LIBRARY-PART-TYPES-V9*

FDMC8327L FDMC86139P I TRX 8 1 0 0 0
TIMESTAMP 2026.07.29.14.07.29
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" FDMC8327L
"Mouser Part Number" 512-FDMC8327L
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi-Fairchild/FDMC8327L?qs=WCuZTSj0%252BHDvMqCYzCnZnA%3D%3D
"Arrow Part Number" FDMC8327L
"Arrow Price/Stock" https://www.arrow.com/en/products/fdmc8327l/on-semiconductor.html?utm_currency=USD&region=nac
"Description" Max rDS(on) = 9.7 m at VGS = 10 V, ID = 12 A ; 100% UIL test ; RoHS Compliant ; Low Profile - 0.8mm max in Power 33 ; Max rDS(on) = 12.5 m at VGS = 4.5 V, ID = 10 A
"Datasheet Link" https://www.onsemi.com/pub/Collateral/FDMC8327L-D.pdf
GATE 1 8 0
FDMC8327L
1 0 U S_1
2 0 U S_2
3 0 U S_3
4 0 U G
5 0 U D_1
6 0 U D_2
7 0 U D_3
8 0 U D_4

*END*
*REMARK* SamacSys ECAD Model
1162474/1853762/2.50/8/2/MOSFET (N-Channel)
